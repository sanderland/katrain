Theme created by Eric W, includes modified board, stones:

* Images taken from [Lizzie](https://github.com/featurecat/lizzie/) by featurecat and contributors.

* Hides hints for low visit/uncertain moves instead of showing small dots. 

Installation:
Unzip this to your .katrain folder in C:\Users\you\.katrain or ~/.katrain

For more information on creating or editing themes, see:
https://github.com/sanderland/katrain/blob/master/THEMES.md

