Created by https://www.reddit.com/user/-koast-/

Installation:
Unzip this to your .katrain folder in C:\Users\you\.katrain or ~/.katrain

For more information on creating or editing themes, see:
https://github.com/sanderland/katrain/blob/master/THEMES.md

